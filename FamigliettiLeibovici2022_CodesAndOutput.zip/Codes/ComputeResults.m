%% Start

clc;
clear;
close all;

%Base directory
    cd 'C:\Dropbox\Shared\RA_Fernando_Jason\Macro_COVID_Revision\ReplicationPackage';
      
%Versions
%=0     if baseline with health policies 
%=1     if baseline with economic policies 
%=2     if appendix #2: Comprehensive policy index 
%=3     if appendix #3: Alternative economic activity variable: Employment 
%=4     if appendix #6: Cross-market reallocation, state-industry-level
%=5     if paper robustness #1: No export destinations
%=6     if paper robustness #2: 3-digit NAICS
%=7     if paper robustness #4: Alternative timing of exports
versions = [0:7];
for i = 1:numel(versions)

    ver = versions(i);

     if ver==0
        %Baseline model with health policies
            batch_dir = {'Excels/Section4'};

            batch_filename = {'coefficients_HS4_containmenthealthindex'};
            var_labels = {'Deaths','Health Containment Policies','Exports'};
            control_vars = {5}; %Including constants    

            output_filename = {'baseline_healthpolicies'};
     elseif ver==1
        %Baseline model with economic policies
            batch_dir = {'Excels/Section4'};
            
            batch_filename = {'coefficients_HS4_economicsupportindex'};
            var_labels = {'Deaths','Economic Support Policies','Exports'};
            control_vars = {5}; %Including constants   
            
            output_filename = {'baseline_econpolicies'};
     elseif ver==2
        %Appendix #2: Comprehensive policy index
            batch_dir = {'Excels/Section4','Excels/Appendix','Excels/Section4','Excels/Appendix'};
            batch_filename = {'coefficients_HS4_containmenthealthindex','coefficients_HS4_governmentresponseindex','coefficients_HS4_economicsupportindex','coefficients_HS4_governmentresponseindex'};
            control_vars = {5,4,5,4}; %Including constants  
            
            var_labels{1} = {'Deaths','Health Containment Policies','Exports'};
            var_labels{2} = {'Deaths','Economic Support Policies','Exports'};            
            
            output_filename = {'appendix_compindex_healthpolicies','appendix_compindex_econpolicies'};
            legend_alt = {'Baseline','Comp. policy index'};
     elseif ver==3
        %Appendix #3: Alternative economic activity variable: Employment
            batch_dir = {'Excels/Section4','Excels/Appendix','Excels/Section4','Excels/Appendix'};
            batch_filename = {'coefficients_HS4_containmenthealthindex','coefficients_HS4_containmenthealthindex_empsubindustry','coefficients_HS4_economicsupportindex','coefficients_HS4_economicsupportindex_empsubindustry'};
            control_vars = {5,5,5,5}; %Including constants  
            
            var_labels{1} = {'Deaths','Health Containment Policies','Economic Activity'};
            var_labels{2} = {'Deaths','Economic Support Policies','Economic Activity'};   
            
            output_filename = {'appendix_emp_healthpolicies','appendix_emp_econpolicies'};
            legend_alt = {'Baseline','Employment'};
     elseif ver==4
        %Appendix #6: Cross-market reallocation, state-industry-level         
            batch_dir = {'Excels/Sections356','Excels/Appendix','Excels/Sections356','Excels/Appendix'};
            batch_filename = {'coefficients_NAICS_containmenthealthindex','coefficients_NAICS_containmenthealthindex','coefficients_NAICS_economicsupportindex','coefficients_NAICS_economicsupportindex'};
            control_vars = {5,6,5,6}; %Including constants  
            
            var_labels{1} = {'Deaths','Health Containment Policies','Exports'};
            var_labels{2} = {'Deaths','Economic Support Policies','Exports'};   
                              
            output_filename = {'appendix_reallocationNAICS_healthpolicies','appendix_reallocationNAICS_econpolicies'};
            legend_alt = {'Baseline','Alternative'};
     elseif ver==5
        %Paper robustness #1: No export destinations
            batch_dir = {'Excels/Section4','Excels/Sections356','Excels/Section4','Excels/Sections356'};
            batch_filename = {'coefficients_HS4_containmenthealthindex','coefficients_HS4_containmenthealthindex_noexportdest','coefficients_HS4_economicsupportindex','coefficients_HS4_economicsupportindex_noexportdest'};
            control_vars = {5,5,5,5}; %Including constants  
            
            var_labels{1} = {'Deaths','Health Containment Policies','Exports'};
            var_labels{2} = {'Deaths','Economic Support Policies','Exports'};   
                              
            output_filename = {'paperSEC5_nodestinations_healthpolicies','paperSEC5_nodestinations_econpolicies'};
            legend_alt = {'Baseline','No Destinations'};
     elseif ver==6
        %Paper robustness #2: 3-digit NAICS
            batch_dir = {'Excels/Section4','Excels/Sections356','Excels/Section4','Excels/Sections356'};
            batch_filename = {'coefficients_HS4_containmenthealthindex','coefficients_NAICS_containmenthealthindex','coefficients_HS4_economicsupportindex','coefficients_NAICS_economicsupportindex'};
            control_vars = {5,5,5,5}; %Including constants  
            
            var_labels{1} = {'Deaths','Health Containment Policies','Exports'};
            var_labels{2} = {'Deaths','Economic Support Policies','Exports'};   
                              
            output_filename = {'paperSEC5_NAICS_healthpolicies','paperSEC5_NAICS_econpolicies'};
            legend_alt = {'Baseline','3-digit NAICS'};
     elseif ver==7
        %Paper robustness #4: Alternative timing of exports
            batch_dir = {'Excels/Section4','Excels/Sections356','Excels/Section4','Excels/Sections356'};
            batch_filename = {'coefficients_HS4_containmenthealthindex','coefficients_HS4_containmenthealthindex_altimingexp','coefficients_HS4_economicsupportindex','coefficients_HS4_economicsupportindex_altimingexp'};
            control_vars = {5,5,5,5}; %Including constants  
            
            var_labels{1} = {'Deaths','Health Containment Policies','Exports'};
            var_labels{2} = {'Deaths','Economic Support Policies','Exports'};   
                                          
            output_filename = {'paperSEC5_altexportiming_healthpolicies','paperSEC5_altexportiming_econpolicies'};
            legend_alt = {'Baseline','Alt. Exp. Timing'};
     end            
   
%Number of bootstraps    
    bootstraps = 10000;  

%Impulse response functions
    periods = 24;

%Figures  
    fig_dir = 'Figures';
    
%Variance decomposition
    vardecomp = 1;
    
%% Loop

for u=1:numel(batch_filename)
    
%% Descriptives

%% Load Data

%Coefficient vector
    [A,~,A_raw] = xlsread([batch_dir{u},'\',batch_filename{u},'.xlsx'],'Coefs');

%Var-covariance matrixVAR
    [varcov,~,varcov_raw] = xlsread([batch_dir{u},'\',batch_filename{u},'.xlsx'],'Coef_VarCov');    
        
%Dimensions
    vars_num = 3*3 + control_vars{u}*3;
    
%Coefficients 
    A_orig = A;

    A_vec = A_orig(1:vars_num);

    A_new(1,:) = A_orig([1:3]);
    A_new(2,:) = A_orig([4+control_vars{u}:6+control_vars{u}]);
    A_new(3,:) = A_orig([7+2*control_vars{u}:9+2*control_vars{u}]);
    A = A_new;

%Variance-covariance matrix       
   varcov = varcov([1:vars_num],[1:vars_num]);
   
   Sigma_Omega(1,1) = A_orig(vars_num+1);
   Sigma_Omega(2,2) = A_orig(vars_num+2);
   Sigma_Omega(3,3) = A_orig(vars_num+3);
   Sigma_Omega(1,2) = A_orig(vars_num+4);
   Sigma_Omega(2,1) = A_orig(vars_num+4);
   Sigma_Omega(3,1) = A_orig(vars_num+5);
   Sigma_Omega(1,3) = A_orig(vars_num+5);
   Sigma_Omega(3,2) = A_orig(vars_num+6);
   Sigma_Omega(2,3) = A_orig(vars_num+6);
   
%% Orthogonalization

%Cholesky
    L = chol(Sigma_Omega,'lower');
    Sigma_Omega_test = L*(L'); %Sigma_Omega_test should equal Sigma_Omega

%Standard deviation of each shock
%QUESTION: IF WE WANTED TO USE STD. DEV. AS THE SHOCK, SHOULD IT BE THIS OR THE ORTHOGONALIZED MATRIX?
    Sigma_Omega_sd = diag(Sigma_Omega).^(1/2);

%% IRFs

shock_policy = 10;

%Key matrix to compute IRFs
    AL = A*L;

%Shock to variable 1
    shock1{u} = [1/AL(1,1);0;0];
    IRF1{u} = zeros(3,24);
    for t=2:periods
        IRF1{u}(:,t) = (A^(t-1))*L*shock1{u};
    end

%Shock to variable 2
    shock2{u} = [0;shock_policy/AL(2,2);0];
    IRF2{u} = zeros(3,24);
    for t=2:periods
        IRF2{u}(:,t) = (A^(t-1))*L*shock2{u};
    end

%Shock to variable 3
    shock3{u} = [0;0;0.10/AL(3,3)];
    IRF3{u} = zeros(3,24);
    for t=2:periods
        IRF3{u}(:,t) = (A^(t-1))*L*shock3{u};
    end

%% Bootstrap CI's

%CI
    ci_ub = 95;
    ci_lb = 5;

%Random number generator seed
    rng('default');

%Bootstrap random draws from distribution
    b = mvnrnd(A_vec,varcov,bootstraps);

%Initialize matrices to compute IRFs for each period
    IRF1_1 = zeros(bootstraps,periods);
    IRF1_2 = zeros(bootstraps,periods);
    IRF1_3 = zeros(bootstraps,periods);
    IRF2_1 = zeros(bootstraps,periods);
    IRF2_2 = zeros(bootstraps,periods);
    IRF2_3 = zeros(bootstraps,periods);
    IRF3_1 = zeros(bootstraps,periods);
    IRF3_2 = zeros(bootstraps,periods);
    IRF3_3 = zeros(bootstraps,periods);

%Loop over simulations
for i = 1:bootstraps
    
    %Transform A vector
        b_orig = b(i,:);

        b_temp(1,:) = b_orig([1:3]);
        b_temp(2,:) = b_orig([4+control_vars{u}:6+control_vars{u}]);
        b_temp(3,:) = b_orig([7+2*control_vars{u}:9+2*control_vars{u}]);

        bL = b_temp*L;
        
    %Initialize temporary IRF matrices
        IRF1_temp = zeros(3,24);
        IRF2_temp = zeros(3,24);
        IRF3_temp = zeros(3,24);
    
    %Calculate impulse responses
        for t=2:periods
            IRF1_temp(:,t) = (b_temp^(t-1))*L*[1/bL(1,1);0;0];
            IRF2_temp(:,t) = (b_temp^(t-1))*L*[0;shock_policy/bL(2,2);0];
            IRF3_temp(:,t) = (b_temp^(t-1))*L*[0;0;0.10/bL(3,3)];
        end
    
    %Assign to proper matrix
        IRF1_1(i,:) = IRF1_temp(1,:);
        IRF1_2(i,:) = IRF1_temp(2,:);
        IRF1_3(i,:) = IRF1_temp(3,:);
        IRF2_1(i,:) = IRF2_temp(1,:);
        IRF2_2(i,:) = IRF2_temp(2,:);
        IRF2_3(i,:) = IRF2_temp(3,:);
        IRF3_1(i,:) = IRF3_temp(1,:);
        IRF3_2(i,:) = IRF3_temp(2,:);
        IRF3_3(i,:) = IRF3_temp(3,:);
        
end

%Compute confidence intervals
    IRF1_1_lowerci{u} = zeros(1,periods);
    IRF1_1_upperci{u} = zeros(1,periods);
    IRF1_2_lowerci{u} = zeros(1,periods);
    IRF1_2_upperci{u} = zeros(1,periods);
    IRF1_3_lowerci{u} = zeros(1,periods);
    IRF1_3_upperci{u} = zeros(1,periods);
    IRF2_1_lowerci{u} = zeros(1,periods);
    IRF2_1_upperci{u} = zeros(1,periods);
    IRF2_2_lowerci{u} = zeros(1,periods);
    IRF2_2_upperci{u} = zeros(1,periods);
    IRF2_3_lowerci{u} = zeros(1,periods);
    IRF2_3_upperci{u} = zeros(1,periods);
    IRF3_1_lowerci{u} = zeros(1,periods);
    IRF3_1_upperci{u} = zeros(1,periods);
    IRF3_2_lowerci{u} = zeros(1,periods);
    IRF3_2_upperci{u} = zeros(1,periods);
    IRF3_3_lowerci{u} = zeros(1,periods);
    IRF3_3_upperci{u} = zeros(1,periods);
    for t=2:periods
        IRF1_1_lowerci{u}(:,t) = prctile(IRF1_1(:,t),ci_lb);
        IRF1_1_upperci{u}(:,t) = prctile(IRF1_1(:,t),ci_ub);
        IRF1_2_lowerci{u}(:,t) = prctile(IRF1_2(:,t),ci_lb);
        IRF1_2_upperci{u}(:,t) = prctile(IRF1_2(:,t),ci_ub);
        IRF1_3_lowerci{u}(:,t) = prctile(IRF1_3(:,t),ci_lb);
        IRF1_3_upperci{u}(:,t) = prctile(IRF1_3(:,t),ci_ub);
        
        IRF2_1_lowerci{u}(:,t) = prctile(IRF2_1(:,t),ci_lb);
        IRF2_1_upperci{u}(:,t) = prctile(IRF2_1(:,t),ci_ub);
        IRF2_2_lowerci{u}(:,t) = prctile(IRF2_2(:,t),ci_lb);
        IRF2_2_upperci{u}(:,t) = prctile(IRF2_2(:,t),ci_ub);
        IRF2_3_lowerci{u}(:,t) = prctile(IRF2_3(:,t),ci_lb);
        IRF2_3_upperci{u}(:,t) = prctile(IRF2_3(:,t),ci_ub);
        
        IRF3_1_lowerci{u}(:,t) = prctile(IRF3_1(:,t),ci_lb);
        IRF3_1_upperci{u}(:,t) = prctile(IRF3_1(:,t),ci_ub);
        IRF3_2_lowerci{u}(:,t) = prctile(IRF3_2(:,t),ci_lb);
        IRF3_2_upperci{u}(:,t) = prctile(IRF3_2(:,t),ci_ub);
        IRF3_3_lowerci{u}(:,t) = prctile(IRF3_3(:,t),ci_lb);
        IRF3_3_upperci{u}(:,t) = prctile(IRF3_3(:,t),ci_ub);
    end

%% Plot figures for section 4

if ver<=1

%Shock to COVID-19 spread
    figure;
    set(gca,'FontName','cmr12');

    subplot(1,3,1); hold on; h1 = plot(1:periods,IRF1{u}(1,:),'LineWidth',2); title(var_labels{1},'fontweight','bold','FontSize',12,'interpreter','latex');
    plot(1:periods, IRF1_1_lowerci{u},'--','color',[0, 0.4470, 0.7410]); plot(1:periods, IRF1_1_upperci{u},'--','color',[0, 0.4470, 0.7410]); hold off; grid on;
    xlim([1 periods]);
    format long;
    ay = ancestor(h1, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',10,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,3,2); hold on; h2 = plot(1:periods,IRF1{u}(2,:),'LineWidth',2); title(var_labels{2},'fontweight','bold','FontSize',12,'interpreter','latex');
    plot(1:periods, IRF1_2_lowerci{u},'--','color',[0, 0.4470, 0.7410]); plot(1:periods, IRF1_2_upperci{u},'--','color',[0, 0.4470, 0.7410]); hold off; grid on;
    xlim([1 periods]);
    format long;
    ay = ancestor(h2, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',10,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,3,3); hold on;
    h3 = plot(1:periods,IRF1{u}(3,:),'LineWidth',2); title(var_labels{3},'fontweight','bold','FontSize',12,'interpreter','latex');
    plot(1:periods, IRF1_3_lowerci{u},'--','color',[0, 0.4470, 0.7410]); plot(1:periods, IRF1_3_upperci{u},'--','color',[0, 0.4470, 0.7410]); hold off; grid on;
    xlim([1 periods]);
    format long;
    ay = ancestor(h3, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',10,'interpreter','latex'); xticks([0 6 12 18 24]);

    sgtitle(['Shock to ' var_labels{1}],'FontSize',14,'interpreter','latex');

    x0 = 1000;
    y0 = 650;
    width = 800;
    height = 250;
    set(gcf,'units','pixels','position',[x0,y0,width,height]);    
  
    print([fig_dir '/IRF_',[output_filename{1}],'_shockspread.eps'],'-depsc');    
    print([fig_dir '/IRF_',[output_filename{1}],'_shockspread.pdf'],'-dpdf','-bestfit');

%Shock to policies    
    figure;
    set(gca,'FontName','cmr12');

    subplot(1,3,1); hold on; h1 = plot(1:periods,IRF2{u}(1,:),'LineWidth',2); title(var_labels{1},'fontweight','bold','FontSize',12,'interpreter','latex');
    plot(1:periods, IRF2_1_lowerci{u},'--','color',[0, 0.4470, 0.7410]); plot(1:periods, IRF2_1_upperci{u},'--','color',[0, 0.4470, 0.7410]); hold off; grid on;
    xlim([1 periods]);
    format long;
    ay = ancestor(h1, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',10,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,3,2); hold on; h2 = plot(1:periods,IRF2{u}(2,:),'LineWidth',2); title(var_labels{2},'fontweight','bold','FontSize',12,'interpreter','latex');
    plot(1:periods, IRF2_2_lowerci{u},'--','color',[0, 0.4470, 0.7410]); plot(1:periods, IRF2_2_upperci{u},'--','color',[0, 0.4470, 0.7410]); hold off; grid on;
    xlim([1 periods]);
    format long;
    ay = ancestor(h2, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',10,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,3,3); hold on;
    h3 = plot(1:periods,IRF2{u}(3,:),'LineWidth',2); title(var_labels{3},'fontweight','bold','FontSize',12,'interpreter','latex');
    plot(1:periods, IRF2_3_lowerci{u},'--','color',[0, 0.4470, 0.7410]); plot(1:periods, IRF2_3_upperci{u},'--','color',[0, 0.4470, 0.7410]); hold off; grid on;
    xlim([1 periods]);
    format long;
    ay = ancestor(h3, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',10,'interpreter','latex'); xticks([0 6 12 18 24]);

    sgtitle(['Shock to ' var_labels{2}],'FontSize',14,'interpreter','latex');

    x0 = 1000;
    y0 = 650;
    width = 800;
    height = 250;
    set(gcf,'units','pixels','position',[x0,y0,width,height]);    
 
    print([fig_dir '/IRF_',[output_filename{1}],'_shockpolicies.eps'],'-depsc');    
    print([fig_dir '/IRF_',[output_filename{1}],'_shockpolicies.pdf'],'-dpdf','-bestfit');
    
end
end

%% Plot figures for section 5 and appendix

if numel(batch_filename)>1
for iter=0:(numel(batch_filename)/2-1)   
    
ind = 1 + 2*iter;    
    
fontsize_sec5 = 8;

%Adjust periods if using weekly data
    periods_1 = 1:periods;
    periods_2_len = periods;

%Shock to COVID-19 spread
    figure;
    set(gca,'FontName','cmr12');

    subplot(1,3,1); hold on; 
    h1 = plot(periods_1,IRF1{ind}(1,:),'LineWidth',2); 
    plot(1:periods_2_len,IRF1{ind+1}(1,1:periods_2_len),'--','LineWidth',2);     
    title(var_labels{iter+1}{1},'fontweight','bold','FontSize',fontsize_sec5,'interpreter','latex');
    hold off; grid on;
    xlim([1 periods_2_len]);
    format long;
    ay = ancestor(h1, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',fontsize_sec5,'interpreter','latex'); xticks([0 6 12 18 24]);

    if iter==0
        if ver>=2
            legend(legend_alt{1},legend_alt{2},'interpreter','latex','FontSize',6,'Position',[0.189452492556777,0.366322820054955,0.184775334312802,0.241443853327297]);
        end
    end
    
    subplot(1,3,2); hold on; 
    h2 = plot(periods_1,IRF1{ind}(2,:),'LineWidth',2); 
    plot(1:periods_2_len,IRF1{ind+1}(2,1:periods_2_len),'--','LineWidth',2); 
    title(var_labels{iter+1}{2},'fontweight','bold','FontSize',fontsize_sec5,'interpreter','latex');
    hold off; grid on;
    xlim([1 periods_2_len]);
    format long;
    ay = ancestor(h2, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',fontsize_sec5,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,3,3); hold on;
    h3 = plot(periods_1,IRF1{ind}(3,:),'LineWidth',2); 
    plot(1:periods_2_len,IRF1{ind+1}(3,1:periods_2_len),'--','LineWidth',2);
    title(var_labels{iter+1}{3},'fontweight','bold','FontSize',fontsize_sec5,'interpreter','latex');
    hold off; grid on;
    xlim([1 periods_2_len]);
    format long;
    ay = ancestor(h3, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',fontsize_sec5,'interpreter','latex'); xticks([0 6 12 18 24]);

    sgtitle(['Shock to ' var_labels{iter+1}{1}],'FontSize',fontsize_sec5+1,'interpreter','latex');

    x0 = 1000*(4/4);
    y0 = 350*(4/4);
    width = 800*(0.70);
    height = 250*(0.50);
    set(gcf,'units','pixels','position',[x0,y0,width,height]);    

    print([fig_dir, '/IRF_',output_filename{iter+1},'_shockspread.pdf'],'-dpdf','-bestfit');
    print([fig_dir, '/IRF_',output_filename{iter+1},'_shockspread.eps'],'-depsc');    

%Shock to policies
    figure;
    set(gca,'FontName','cmr12');

    subplot(1,3,1); hold on; 
    h1 = plot(periods_1,IRF2{ind}(1,:),'LineWidth',2); 
    plot(1:periods_2_len,IRF2{ind+1}(1,1:periods_2_len),'--','LineWidth',2); 
    title(var_labels{iter+1}{1},'fontweight','bold','FontSize',fontsize_sec5,'interpreter','latex');
    hold off; grid on;
    xlim([1 periods_2_len]);
    format long;
    ay = ancestor(h1, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',fontsize_sec5,'interpreter','latex'); xticks([0 6 12 18 24]);
    
    subplot(1,3,2); hold on; 
    h2 = plot(periods_1,IRF2{ind}(2,:),'LineWidth',2); 
    plot(1:periods_2_len,IRF2{ind+1}(2,1:periods_2_len),'--','LineWidth',2); 
    title(var_labels{iter+1}{2},'fontweight','bold','FontSize',fontsize_sec5,'interpreter','latex');
    hold off; grid on;
    xlim([1 periods_2_len]);
    format long;
    ay = ancestor(h2, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',fontsize_sec5,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,3,3); hold on;
    h3 = plot(periods_1,IRF2{ind}(3,:),'LineWidth',2); 
    plot(1:periods_2_len,IRF2{ind+1}(3,1:periods_2_len),'--','LineWidth',2);
    title(var_labels{iter+1}{3},'fontweight','bold','FontSize',fontsize_sec5,'interpreter','latex');
    hold off; grid on;
    xlim([1 periods_2_len]);
    format long;
    ay = ancestor(h3, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',fontsize_sec5,'interpreter','latex'); xticks([0 6 12 18 24]);

    sgtitle(['Shock to ' var_labels{iter+1}{2}],'FontSize',fontsize_sec5+1,'interpreter','latex');

    x0 = 1000*(4/4);
    y0 = 350*(4/4);
    width = 800*(0.70);
    height = 250*(0.50);
    set(gcf,'units','pixels','position',[x0,y0,width,height]);    

    print([fig_dir '/IRF_',output_filename{iter+1},'_shockpolicies.pdf'],'-dpdf','-bestfit');
    print([fig_dir '/IRF_',output_filename{iter+1},'_shockpolicies.eps'],'-depsc');
    
end
end
    
%% Variance decomposition

if ver<=1 && vardecomp==1

%Settings
    %Number of time series simulated
        vd_ts = 100;

    %Number of periods simulated for each time series
        vd_num = 1012; 

    %Number of periods burnt    
        burn = 1000;

    %Number of variables    
        vars = 3;

%Random number generator seed    
    rng('default');

for vd_iter=1:vd_ts

    %Draw shocks
        eee = mvnrnd(0*ones(3,1),eye(3,3),vd_num+1)';

    %Matrices used to simulate model    
        inv_L = inv(L);
        inv_L_SigmaOmega = inv_L*Sigma_Omega;
        inv_L_A = inv_L*A;

    %Simulate model with all shocks
        eee_all = eee;
        y_all = zeros(3,vd_num+1);
        for vd_t=2:vd_num+1
            for vd_var=1:3
                if vd_var==1
                    y_all(1,vd_t) = (                                                         inv_L_A(1,:)*y_all(:,vd_t-1) + eee_all(1,vd_t))/inv_L(1,1);
                elseif vd_var==2
                    y_all(2,vd_t) = (-inv_L(2,1)*y_all(1,vd_t)                              + inv_L_A(2,:)*y_all(:,vd_t-1) + eee_all(2,vd_t))/inv_L(2,2);
                elseif vd_var==3
                    y_all(3,vd_t) = (-inv_L(3,1)*y_all(1,vd_t) - inv_L(3,2)*y_all(2,vd_t)   + inv_L_A(3,:)*y_all(:,vd_t-1) + eee_all(3,vd_t))/inv_L(3,3);
                end
            end
        end
        y_all = y_all(:,burn+1:end);

    %Simulate model with first and second shock
        eee_12 = zeros(3,vd_num+1);
        eee_12(1,:) = eee(1,:);
        eee_12(2,:) = eee(2,:);
        y_12 = zeros(3,vd_num+1);
        for vd_t=2:vd_num+1
            for vd_var=1:3
                if vd_var==1
                    y_12(1,vd_t) = (                                                       inv_L_A(1,:)*y_12(:,vd_t-1) + eee_12(1,vd_t))/inv_L(1,1);
                elseif vd_var==2
                    y_12(2,vd_t) = (-inv_L(2,1)*y_12(1,vd_t)                             + inv_L_A(2,:)*y_12(:,vd_t-1) + eee_12(2,vd_t))/inv_L(2,2);
                elseif vd_var==3
                    y_12(3,vd_t) = (-inv_L(3,1)*y_12(1,vd_t) - inv_L(3,2)*y_12(2,vd_t)   + inv_L_A(3,:)*y_12(:,vd_t-1) + eee_12(3,vd_t))/inv_L(3,3);
                end
            end
        end
        y_12 = y_12(:,burn+1:end);        
        
    %Simulate model with first shock
        eee_1 = zeros(3,vd_num+1);
        eee_1(1,:) = eee(1,:);
        y_1 = zeros(3,vd_num+1);
        for vd_t=2:vd_num+1
            for vd_var=1:3
                if vd_var==1
                    y_1(1,vd_t) = (                                                   inv_L_A(1,:)*y_1(:,vd_t-1) + eee_1(1,vd_t))/inv_L(1,1);
                elseif vd_var==2
                    y_1(2,vd_t) = (-inv_L(2,1)*y_1(1,vd_t)                          + inv_L_A(2,:)*y_1(:,vd_t-1) + eee_1(2,vd_t))/inv_L(2,2);
                elseif vd_var==3
                    y_1(3,vd_t) = (-inv_L(3,1)*y_1(1,vd_t) - inv_L(3,2)*y_1(2,vd_t) + inv_L_A(3,:)*y_1(:,vd_t-1) + eee_1(3,vd_t))/inv_L(3,3);
                end
            end
        end
        y_1 = y_1(:,burn+1:end);

    %Simulate model with second shock
        eee_2 = zeros(3,vd_num+1);
        eee_2(2,:) = eee(2,:);
        y_2 = zeros(3,vd_num+1);
        for vd_t=2:vd_num+1
            for vd_var=1:3
                if vd_var==1
                    y_2(1,vd_t) = (                                                   inv_L_A(1,:)*y_2(:,vd_t-1) + eee_2(1,vd_t))/inv_L(1,1);
                elseif vd_var==2
                    y_2(2,vd_t) = (-inv_L(2,1)*y_2(1,vd_t)                          + inv_L_A(2,:)*y_2(:,vd_t-1) + eee_2(2,vd_t))/inv_L(2,2);
                elseif vd_var==3
                    y_2(3,vd_t) = (-inv_L(3,1)*y_2(1,vd_t) - inv_L(3,2)*y_2(2,vd_t) + inv_L_A(3,:)*y_2(:,vd_t-1) + eee_2(3,vd_t))/inv_L(3,3);
                end
            end
        end
        y_2 = y_2(:,burn+1:end);

    %Simulate model with third shock
        eee_3 = zeros(3,vd_num+1);
        eee_3(3,:) = eee(3,:);
        y_3 = zeros(3,vd_num+1);
        for vd_t=2:vd_num+1
            for vd_var=1:3
                if vd_var==1
                    y_3(1,vd_t) = (                                                   inv_L_A(1,:)*y_3(:,vd_t-1) + eee_3(1,vd_t))/inv_L(1,1);
                elseif vd_var==2
                    y_3(2,vd_t) = (-inv_L(2,1)*y_3(1,vd_t)                          + inv_L_A(2,:)*y_3(:,vd_t-1) + eee_3(2,vd_t))/inv_L(2,2);
                elseif vd_var==3
                    y_3(3,vd_t) = (-inv_L(3,1)*y_3(1,vd_t) - inv_L(3,2)*y_3(2,vd_t) + inv_L_A(3,:)*y_3(:,vd_t-1) + eee_3(3,vd_t))/inv_L(3,3);
                end
            end
        end
        y_3 = y_3(:,burn+1:end);

    %Variance decomposition with 2 shocks
        vardecomp_2shocks.v1_e1(vd_iter) = var(y_1(1,:))/(var(y_1(1,:)) + var(y_2(1,:)));
        vardecomp_2shocks.v1_e2(vd_iter) = var(y_2(1,:))/(var(y_1(1,:)) + var(y_2(1,:)));

        vardecomp_2shocks.v2_e1(vd_iter) = var(y_1(2,:))/(var(y_1(2,:)) + var(y_2(2,:)));
        vardecomp_2shocks.v2_e2(vd_iter) = var(y_2(2,:))/(var(y_1(2,:)) + var(y_2(2,:)));

        vardecomp_2shocks.v3_e1(vd_iter) = var(y_1(3,:))/(var(y_1(3,:)) + var(y_2(3,:)));
        vardecomp_2shocks.v3_e2(vd_iter) = var(y_2(3,:))/(var(y_1(3,:)) + var(y_2(3,:)));

end

table_vardecomp{1+ver}(1,:) = [mean(vardecomp_2shocks.v1_e1) mean(vardecomp_2shocks.v1_e2)];
table_vardecomp{1+ver}(2,:) = [mean(vardecomp_2shocks.v2_e1) mean(vardecomp_2shocks.v2_e2)];
table_vardecomp{1+ver}(3,:) = [mean(vardecomp_2shocks.v3_e1) mean(vardecomp_2shocks.v3_e2)];

xlswrite('Excels\Section4\VarDecomp.xlsx',table_vardecomp{1+ver},['sheet' num2str(1+ver)]);

end

%% Figure 8

if ver==0

%Save model IRFs
    IRF1_Fig8 = IRF1{1}';
    IRF2_Fig8 = IRF2{1}';

    xlswrite('Excels\Sections356\IRF_baseline.xlsx',IRF1_Fig8,'health_shock_case');
    xlswrite('Excels\Sections356\IRF_baseline.xlsx',IRF2_Fig8,'health_shock_pol');    

%Load results from workbook "regression_output.xls"
    [Coeffs,~,Coeffs_Raw] = xlsread('Excels\Sections356\regression_output.xls');

%Weights
    Periods = zeros(24,1);
    EmpResponse_Case = zeros(24,1);
    EmpResponse_Policy = zeros(24,1);

    for i = 1:24
        Periods(i) = i;
        EmpResponse_Case(i) = IRF1_Fig8(i,1)*Coeffs(2) + IRF1_Fig8(i,2)*Coeffs(3) + IRF1_Fig8(i,3)*Coeffs(1);
        EmpResponse_Policy(i) = IRF2_Fig8(i,1)*Coeffs(2) + IRF2_Fig8(i,2)*Coeffs(3) + IRF2_Fig8(i,3)*Coeffs(1);
    end

%Plot Implied Impulse Response Functions
    font_size_title = 12;
    font_size = 11;

    figure;
    set(gcf,'Position',[209 297.6666666666666 711 240.3333333333334])
    subplot(1,2,1); hold on; h1 = plot(Periods,EmpResponse_Case,'LineWidth',2); title('Shock to Deaths: Employment Response','fontweight','bold','FontSize',font_size,'interpreter','latex');
    h1 = plot(Periods,IRF1_Fig8(:,3),'LineWidth',2); title('Shock to Deaths','fontweight','bold','FontSize',font_size,'interpreter','latex'); hold off; grid on;
    format long;
    ay = ancestor(h1, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',font_size,'interpreter','latex'); xticks([0 6 12 18 24]);

    subplot(1,2,2); hold on; h2 = plot(Periods,EmpResponse_Policy,'LineWidth',2); title('Shock to Policies','fontweight','bold','FontSize',font_size,'interpreter','latex');
    h2 = plot(Periods,IRF2_Fig8(:,3),'LineWidth',2); title('Shock to Health Containment Policies','fontweight','bold','FontSize',font_size,'interpreter','latex');
    hold off; grid on;
    format long;
    ay = ancestor(h2, 'axes');
    ay.YAxis.Exponent = 0;
    xlabel('Months','FontSize',font_size,'interpreter','latex'); xticks([0 6 12 18 24]);

    legend('Employment','Exports','interpreter','latex','FontSize',font_size,'Position',[0.24,0.366322820054955,0.184775334312802,0.10]);

%Print
    print('Figures\implied_employment_IRFs.pdf','-dpdf','-bestfit');
    print('Figures\implied_employment_IRFs.eps','-depsc');

end
    
end



