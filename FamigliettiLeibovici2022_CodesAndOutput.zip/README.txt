================================
Famiglietti and Leibovici (2022)
--------------------------------
REPLICATION PACKAGE
================================

=====================
Software requirements
=====================

The software we used to compute the results is (i) Stata 15.1, and (ii) Matlab R2019a

===================
Step #1: Setup data
===================

1. Open Codes\DataSetup.do

2. Update directory in line 5: Set it to base directory containing all folders of the replication package 

3. Use Stata to run Codes\DataSetup.do

=====================
Step #2: Process data
=====================

1. Open Codes\DataProcessing.do

2. Update directory in line 7: Set it to base directory containing all folders of the replication package 

3. Use Stata to run Codes\DataProcessing.do 

========================
Step #3: Compute results
========================

1. Open Codes\ComputeResults.m

2. Update directory in line 8: Set it to base directory containing all folders of the replication package 

3. Use Matlab to run Codes\ComputeResults.m

===============================================
Step #4: Collect results presented in the paper
===============================================

Table 1: Tables\state_month_mean_statistics.tex
		 Tables\state_month_max_statistics.tex
		 Tables\disaggregated_export_statistics.tex
		 
Figure 1: Figures\IRF_baseline_healthpolicies_shockspread.eps
		  Figures\IRF_baseline_healthpolicies_shockpolicies.eps
		  
Figure 2: Figures\IRF_baseline_econpolicies_shockspread.eps
		  Figures\IRF_baseline_econpolicies_shockpolicies.eps		  
		  
Table 2: Excels\Section4\VarDecomp.xlsx

Figure 3: Figures\timeseries_healthpolicy_allgroups.pdf
		  Figures\timeseries_exports_allgroups.pdf
		  Figures\timeseries_deaths_allgroups.pdf
		  Figures\timeseries_emp_allgroups.pdf

Figure 4: Figures\IRF_paperSEC5_nodestinations_healthpolicies_shockspread.eps
		  Figures\IRF_paperSEC5_nodestinations_healthpolicies_shockpolicies.eps
		  Figures\IRF_paperSEC5_nodestinations_econpolicies_shockspread.eps
		  Figures\IRF_paperSEC5_nodestinations_econpolicies_shockpolicies.eps	
		  
Figure 5: Figures\IRF_paperSEC5_NAICS_healthpolicies_shockspread.eps
		  Figures\IRF_paperSEC5_NAICS_healthpolicies_shockpolicies.eps
		  Figures\IRF_paperSEC5_NAICS_econpolicies_shockspread.eps
		  Figures\IRF_paperSEC5_NAICS_econpolicies_shockpolicies.eps			  
		  
Figure 6: Figures\IRF_paperSEC5_altexportiming_healthpolicies_shockspread.eps
		  Figures\IRF_paperSEC5_altexportiming_healthpolicies_shockpolicies.eps
		  Figures\IRF_paperSEC5_altexportiming_econpolicies_shockspread.eps
		  Figures\IRF_paperSEC5_altexportiming_econpolicies_shockpolicies.eps		

Figure 7: Figures\implied_employment_IRFs.eps

==================================================
Step #5: Collect results presented in the appendix
==================================================

Table 1: Tables\RegressionOutput.log

Figure 1: Figures\IRF_appendix_compindex_healthpolicies_shockspread.eps
		  Figures\IRF_appendix_compindex_healthpolicies_shockpolicies.eps
		  Figures\IRF_appendix_compindex_econpolicies_shockspread.eps
		  Figures\IRF_appendix_compindex_econpolicies_shockpolicies.eps	 

Figure 2: Figures\IRF_appendix_emp_healthpolicies_shockspread.eps
		  Figures\IRF_appendix_emp_healthpolicies_shockpolicies.eps
		  Figures\IRF_appendix_emp_econpolicies_shockspread.eps
		  Figures\IRF_appendix_emp_econpolicies_shockpolicies.eps	 
		  
Figure 3: Figures\IRF_appendix_reallocationNAICS_healthpolicies_shockspread.eps
		  Figures\IRF_appendix_reallocationNAICS_healthpolicies_shockpolicies.eps
		  Figures\IRF_appendix_reallocationNAICS_econpolicies_shockspread.eps
		  Figures\IRF_appendix_reallocationNAICS_econpolicies_shockpolicies.eps			  